import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";

export async function POST() {
  const user = await requireUser();

  return NextResponse.json({
    ok: true,
    data: {
      userId: user.id,
      amount: 100,
      status: "stub",
      message: "Phase 1 stub. Phase 2 will validate cooldown and write coin_ledger server-side."
    }
  });
}
