"use client";

import { useEffect, useMemo, useState } from "react";

type PredictionOption = {
  name: string;
  returns: number;
};

type Question = {
  id: number;
  tournament: string;
  title: string;
  closeOffsetMinutes: number;
  options: PredictionOption[];
};

type HistoryItem = {
  month: string;
  date: string;
  time: string;
  action: "Claim" | "Predict" | "Payout" | "Refund";
  detail: string;
  amount: number;
};

type RunningPrediction = {
  id: number;
  questionId: number;
  question: string;
  answer: string;
  coins: number;
  returns: number;
  status: "Running";
};

declare global {
  interface Window {
    google?: {
      translate?: {
        TranslateElement: new (
          options: { pageLanguage: string; includedLanguages: string; layout: unknown },
          elementId: string
        ) => void;
      };
    };
    googleTranslateElementInit?: () => void;
  }
}

const questions: Question[] = [
  {
    id: 1,
    tournament: "Super League",
    title: "Which team will win the championship?",
    closeOffsetMinutes: 4300,
    options: [
      { name: "Alpha Esports", returns: 185 },
      { name: "Bravo Gaming", returns: 230 },
      { name: "Charlie Squad", returns: 310 },
      { name: "Delta Force", returns: 420 },
      { name: "Echo Team", returns: 560 },
      { name: "Falcon", returns: 690 },
      { name: "Ghost", returns: 760 },
      { name: "Hydra", returns: 840 },
      { name: "Inferno", returns: 920 },
      { name: "Joker", returns: 980 }
    ]
  },
  {
    id: 2,
    tournament: "Global Open",
    title: "Which region will finish first?",
    closeOffsetMinutes: 1480,
    options: [
      { name: "SEA", returns: 210 },
      { name: "South Asia", returns: 280 },
      { name: "Europe", returns: 340 },
      { name: "Americas", returns: 410 },
      { name: "Middle East", returns: 530 },
      { name: "Wildcard", returns: 720 }
    ]
  },
  {
    id: 3,
    tournament: "Scrim Night",
    title: "Most kills team in final map?",
    closeOffsetMinutes: 360,
    options: [
      { name: "Rex", returns: 260 },
      { name: "Nova", returns: 275 },
      { name: "Viper", returns: 330 },
      { name: "Ghost", returns: 380 },
      { name: "Blaze", returns: 430 },
      { name: "Frost", returns: 510 },
      { name: "Omega", returns: 620 },
      { name: "Ruin", returns: 700 }
    ]
  },
  {
    id: 4,
    tournament: "Weekly Final",
    title: "Which team gets the first chicken dinner?",
    closeOffsetMinutes: 90,
    options: [
      { name: "Alpha", returns: 220 },
      { name: "Bravo", returns: 260 },
      { name: "Charlie", returns: 335 },
      { name: "Delta", returns: 430 },
      { name: "Echo", returns: 520 },
      { name: "Falcon", returns: 640 }
    ]
  }
];

const defaultHistory: HistoryItem[] = [
  { month: "May 2026", date: "26 May", time: "16:02", action: "Claim", detail: "Hourly reward", amount: 100 },
  { month: "May 2026", date: "26 May", time: "16:10", action: "Predict", detail: "Super League · Alpha Esports", amount: -500 },
  { month: "May 2026", date: "26 May", time: "16:38", action: "Payout", detail: "Super League resolved", amount: 890 },
  { month: "April 2026", date: "22 Apr", time: "20:14", action: "Claim", detail: "Hourly reward", amount: 100 },
  { month: "April 2026", date: "22 Apr", time: "20:21", action: "Predict", detail: "Global Open · SEA", amount: -600 }
];

const defaultLeaderboard: [string, number][] = [
  ["Maverick", 18500],
  ["Nova", 16320],
  ["Raptor", 14110],
  ["Echo", 11940],
  ["Vector", 9800],
  ["Ruin", 8120],
  ["Ghost", 7400],
  ["Blaze", 6200],
  ["Frost", 5900],
  ["You", 0]
];

function money(amount: number) {
  return `${amount >= 0 ? "+" : ""}${amount}`;
}

function currentMonth() {
  return "May 2026";
}

function currentDateLabel() {
  return "26 May";
}

function currentTimeLabel() {
  const now = new Date();
  return `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
}

function safeJson<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function createQuestionDeadlines() {
  return Object.fromEntries(questions.map((question) => [question.id, Date.now() + question.closeOffsetMinutes * 60000]));
}

export default function SuperWinPrototype() {
  const [mounted, setMounted] = useState(false);
  const [loggedIn, setLoggedIn] = useState(false);
  const [coins, setCoins] = useState(500);
  const [profit, setProfit] = useState(0);
  const [nextClaimAt, setNextClaimAt] = useState(0);
  const [activeQuestion, setActiveQuestion] = useState<number | null>(null);
  const [openDropdown, setOpenDropdown] = useState<number | null>(null);
  const [selected, setSelected] = useState<Record<number, string>>(
    Object.fromEntries(questions.map((question) => [question.id, question.options[0].name]))
  );
  const [coinInputs, setCoinInputs] = useState<Record<number, number>>({});
  const [history, setHistory] = useState<HistoryItem[]>(defaultHistory);
  const [historyFilter, setHistoryFilter] = useState<"All" | HistoryItem["action"]>("All");
  const [historyPage, setHistoryPage] = useState(1);
  const [running, setRunning] = useState<RunningPrediction[]>([]);
  const [questionDeadlines, setQuestionDeadlines] = useState<Record<number, number>>({});
  const [claimLabel, setClaimLabel] = useState("Ready");
  const [monthLabel, setMonthLabel] = useState("--");
  const [openModal, setOpenModal] = useState<"history" | "running" | "info" | null>(null);
  const [toast, setToast] = useState<Record<number, string>>({});

  useEffect(() => {
    setMounted(true);
    setCoins(Number(localStorage.getItem("sr_coins")) || 500);
    setProfit(Number(localStorage.getItem("sr_profit")) || 0);
    setNextClaimAt(Number(localStorage.getItem("sr_next_claim")) || 0);
    setHistory(safeJson("sr_history", defaultHistory).slice(0, 500));
    setRunning(safeJson("sr_running", []));
    const deadlines = safeJson<Record<number, number> | null>("sr_question_deadlines", null) || createQuestionDeadlines();
    setQuestionDeadlines(deadlines);
    localStorage.setItem("sr_question_deadlines", JSON.stringify(deadlines));
  }, []);

  useEffect(() => {
    if (!mounted) return;
    localStorage.setItem("sr_coins", String(coins));
    localStorage.setItem("sr_profit", String(profit));
    localStorage.setItem("sr_next_claim", String(nextClaimAt));
    localStorage.setItem("sr_history", JSON.stringify(history.slice(0, 500)));
    localStorage.setItem("sr_running", JSON.stringify(running.slice(0, 30)));
  }, [coins, profit, nextClaimAt, history, running, mounted]);

  useEffect(() => {
    if (!mounted) return;
    window.googleTranslateElementInit = function () {
      if (!window.google?.translate) return;
      new window.google.translate.TranslateElement(
        {
          pageLanguage: "en",
          includedLanguages: "en,th,id,ms,vi,zh-CN,ja,ko",
          layout: "SIMPLE"
        },
        "google_translate_element"
      );
    };
    if (!document.querySelector("script[data-google-translate]")) {
      const script = document.createElement("script");
      script.src = "https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
      script.async = true;
      script.setAttribute("data-google-translate", "true");
      document.body.appendChild(script);
    }
  }, [mounted]);

  useEffect(() => {
    const tick = () => {
      const claimRemaining = nextClaimAt - Date.now();
      if (claimRemaining <= 0) {
        setClaimLabel("Ready");
      } else {
        const minutes = Math.floor(claimRemaining / 60000);
        const seconds = Math.floor((claimRemaining % 60000) / 1000);
        setClaimLabel(`${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`);
      }

      const now = new Date();
      const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 1, 0, 0, 0, 0);
      const monthRemaining = Math.max(0, monthEnd.getTime() - now.getTime());
      const days = Math.floor(monthRemaining / 86400000);
      const hours = Math.floor((monthRemaining % 86400000) / 3600000);
      const minutes = Math.floor((monthRemaining % 3600000) / 60000);
      setMonthLabel(`${days}d ${hours}h ${minutes}m`);
    };
    tick();
    const timer = window.setInterval(tick, 1000);
    return () => window.clearInterval(timer);
  }, [nextClaimAt]);

  const leaderboard = useMemo(() => {
    const rows = defaultLeaderboard.map((row) => (row[0] === "You" ? [row[0], profit] as [string, number] : row));
    return rows.sort((a, b) => b[1] - a[1]).slice(0, 10);
  }, [profit]);

  const userRank = leaderboard.findIndex((row) => row[0] === "You") + 1;

  const openQuestions = questions.filter((question) => Date.now() < Number(questionDeadlines[question.id] || 0));

  const filteredHistory = historyFilter === "All" ? history : history.filter((item) => item.action === historyFilter);
  const historyTotalPages = Math.max(1, Math.ceil(filteredHistory.length / 10));
  const historyRows = filteredHistory.slice((historyPage - 1) * 10, historyPage * 10);

  function selectedOption(question: Question) {
    return question.options.find((option) => option.name === selected[question.id]) || question.options[0];
  }

  function formatQuestionCountdown(question: Question) {
    const remaining = Math.max(0, Number(questionDeadlines[question.id] || 0) - Date.now());
    const days = Math.floor(remaining / 86400000);
    const hours = Math.floor((remaining % 86400000) / 3600000);
    const minutes = Math.floor((remaining % 3600000) / 60000);
    if (days > 0) return `${days}d ${hours}h ${minutes}m`;
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  }

  function claim() {
    if (!loggedIn || Date.now() < nextClaimAt) return;
    setCoins((current) => current + 100);
    setNextClaimAt(Date.now() + 60 * 60 * 1000);
    setHistory((current) => [
      { month: currentMonth(), date: currentDateLabel(), time: currentTimeLabel(), action: "Claim" as const, detail: "Hourly reward", amount: 100 },
      ...current
    ].slice(0, 500));
  }

  function confirmPrediction(question: Question) {
    const amount = Number(coinInputs[question.id] || 0);
    const answer = selectedOption(question);
    if (!loggedIn) {
      setToast((current) => ({ ...current, [question.id]: "Login first" }));
      return;
    }
    if (Date.now() >= Number(questionDeadlines[question.id] || 0)) return;
    if (!amount || amount < 1) {
      setToast((current) => ({ ...current, [question.id]: "Choose coins for this question" }));
      return;
    }
    if (amount > coins) {
      setToast((current) => ({ ...current, [question.id]: "Not enough coins" }));
      return;
    }

    setCoins((current) => current - amount);
    setProfit((current) => current - amount);
    setHistory((current) => [
      {
        month: currentMonth(),
        date: currentDateLabel(),
        time: currentTimeLabel(),
        action: "Predict" as const,
        detail: `${question.title} · ${answer.name} · approx. ${answer.returns}%`,
        amount: -amount
      },
      ...current
    ].slice(0, 500));
    setRunning((current) => [
      {
        id: Date.now(),
        questionId: question.id,
        question: question.title,
        answer: answer.name,
        coins: amount,
        returns: answer.returns,
        status: "Running" as const
      },
      ...current
    ].slice(0, 30));
    setCoinInputs((current) => ({ ...current, [question.id]: 0 }));
    setToast((current) => ({ ...current, [question.id]: `${amount} coins used on ${answer.name} · now running` }));
  }

  function resetDemo() {
    ["sr_coins", "sr_profit", "sr_next_claim", "sr_history", "sr_running", "sr_question_deadlines"].forEach((key) => localStorage.removeItem(key));
    window.location.reload();
  }

  return (
    <main className="page">
      <div className="app">
        <header className="topbar">
          <div className="brand">
            <img className="logo" src="/SuperWin_b.png" alt="SuperWin logo" />
            <div className="brand-text">
              <h1>SUPERWIN RETURN</h1>
              <span>Prediction Room</span>
            </div>
          </div>
          <div className="actions">
            <span className="pill gold"><span>{coins}</span> Coins</span>
            <button className="button primary" disabled={claimLabel !== "Ready"} onClick={claim}>Claim 100</button>
            <button className="button gold" onClick={() => setOpenModal("running")}>Running {running.length}</button>
            <button className="button gold" onClick={() => { setHistoryPage(1); setOpenModal("history"); }}>History</button>
            <button className="button gold" onClick={() => setOpenModal("info")}>Info</button>
            <button className="button gold" onClick={resetDemo}>Reset Demo</button>
            <button className="button" onClick={() => setLoggedIn(true)}>{loggedIn ? "Account" : "Login"}</button>
          </div>
        </header>

        <section className="stats" aria-label="Account stats">
          <div className="stat"><span className="label">Monthly Profit</span><b className="value">{profit}</b></div>
          <div className="stat"><span className="label">Monthly Rank</span><b className="value">{userRank ? `#${userRank}` : "--"}</b></div>
          <div className="stat"><span className="label">Next Claim</span><b className="value">{claimLabel}</b></div>
          <div className="stat"><span className="label">Month Ends</span><b className="value">{monthLabel}</b></div>
        </section>

        <section className="content">
          <section className="panel">
            <div className="panel-head"><h2>Super League</h2><span className="micro">Select a question</span></div>
            <div className="questions">
              {openQuestions.length ? openQuestions.map((question) => {
                const option = selectedOption(question);
                const runningCount = running.filter((item) => item.questionId === question.id).length;
                const isActive = activeQuestion === question.id;
                return (
                  <div key={question.id} className={`question ${isActive ? "active" : ""} ${runningCount ? "running" : ""}`} onClick={(event) => {
                    if ((event.target as HTMLElement).closest("button")) return;
                    setActiveQuestion(question.id);
                    setOpenDropdown(null);
                  }}>
                    <div className="question-top">
                      <div className="question-main">
                        <span className="question-title">{question.title}</span>
                        <span className="meta">Closes in {formatQuestionCountdown(question)}{runningCount ? ` · ${runningCount} running` : ""}</span>
                      </div>
                      <div className={`dropdown ${openDropdown === question.id ? "open" : ""}`}>
                        <button className="dropdown-trigger" onClick={(event) => {
                          event.stopPropagation();
                          setActiveQuestion(question.id);
                          setOpenDropdown(openDropdown === question.id ? null : question.id);
                        }}>
                          <span className="dropdown-label">{option.name} · ~{option.returns}%</span>
                        </button>
                        <div className="dropdown-menu">
                          {question.options.map((choice) => (
                            <button key={choice.name} className={`option-button ${choice.name === option.name ? "active" : ""}`} onClick={(event) => {
                              event.stopPropagation();
                              setSelected((current) => ({ ...current, [question.id]: choice.name }));
                              setOpenDropdown(null);
                            }}>
                              <span>{choice.name}</span><span className="return">~{choice.returns}%</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="question-action">
                      <div className="amounts">
                        {[10, 20, 50, 100].map((amount) => (
                          <button key={amount} className="button gold" onClick={() => setCoinInputs((current) => ({ ...current, [question.id]: Number(current[question.id] || 0) + amount }))}>{amount}</button>
                        ))}
                      </div>
                      <input type="number" min={1} placeholder="Coins for this question" value={coinInputs[question.id] || ""} onChange={(event) => setCoinInputs((current) => ({ ...current, [question.id]: Number(event.target.value) }))} />
                      <button className="button primary confirm" onClick={() => confirmPrediction(question)}>Predict</button>
                    </div>
                    <div className="toast">{toast[question.id]}</div>
                  </div>
                );
              }) : <div className="question"><span className="question-title">No open questions</span><span className="meta">Submitted predictions are waiting in Running</span></div>}
            </div>
          </section>

          <aside className="side">
            <section className="panel">
              <div className="panel-head"><h3>Monthly Top 10</h3><span className="micro">Profit this month</span></div>
              <div className="leaderboard-body">
                {leaderboard.map((row, index) => <div key={row[0]} className="rank"><span>{index + 1}</span><span>{row[0]}</span><b>{money(row[1])}</b></div>)}
              </div>
            </section>
            <section className="panel">
              <div className="panel-head"><h3>Prize</h3><span className="micro">Rank 1</span></div>
              <div className="reward">
                <div className="reward-line"><span>Reward</span><b className="accent-gold">Monthly Prize</b></div>
                <div className="reward-line"><span>Winner by</span><b className="accent-gold">Monthly Profit</b></div>
                <div className="reward-line"><span>Proof</span><b className="accent-gold">After Completed</b></div>
              </div>
            </section>
          </aside>
        </section>
      </div>

      {openModal === "history" && <HistoryModal historyRows={historyRows} historyFilter={historyFilter} historyPage={historyPage} historyTotalPages={historyTotalPages} setHistoryFilter={setHistoryFilter} setHistoryPage={setHistoryPage} onClose={() => setOpenModal(null)} />}
      {openModal === "running" && <RunningModal running={running} onClose={() => setOpenModal(null)} />}
      {openModal === "info" && <InfoModal onClose={() => setOpenModal(null)} />}
    </main>
  );
}

function HistoryModal({
  historyRows,
  historyFilter,
  historyPage,
  historyTotalPages,
  setHistoryFilter,
  setHistoryPage,
  onClose
}: {
  historyRows: HistoryItem[];
  historyFilter: "All" | HistoryItem["action"];
  historyPage: number;
  historyTotalPages: number;
  setHistoryFilter: (value: "All" | HistoryItem["action"]) => void;
  setHistoryPage: (value: number) => void;
  onClose: () => void;
}) {
  return (
    <section className="modal open" aria-label="Coin history" onClick={(event) => event.target === event.currentTarget && onClose()}>
      <div className="modal-card">
        <div className="modal-head"><h3>Coin History</h3><button className="button" onClick={onClose}>Close</button></div>
        <div className="modal-body">
          <div className="filter-row">
            {(["All", "Predict", "Claim", "Payout"] as const).map((filter) => (
              <button key={filter} className={`button ${historyFilter === filter ? "active" : ""}`} onClick={() => { setHistoryFilter(filter); setHistoryPage(1); }}>{filter}</button>
            ))}
          </div>
          <div>
            {historyRows.length ? historyRows.map((row, index) => (
              <div key={`${row.date}-${row.time}-${index}`} className="history-row">
                <span>{row.date}</span><span>{row.time}</span><span>{row.action}</span><span>{row.detail}</span><b className={row.amount >= 0 ? "accent-gold" : "accent-red"}>{money(row.amount)}</b>
              </div>
            )) : <div className="history-row"><span>No {historyFilter} history</span><b className="accent-gold">0</b></div>}
          </div>
          <div className="history-footer">
            <button className="button" disabled={historyPage <= 1} onClick={() => setHistoryPage(historyPage - 1)}>Prev</button>
            <span className="micro">Page {historyPage} / {historyTotalPages}</span>
            <button className="button" disabled={historyPage >= historyTotalPages} onClick={() => setHistoryPage(historyPage + 1)}>Next</button>
          </div>
        </div>
      </div>
    </section>
  );
}

function RunningModal({ running, onClose }: { running: RunningPrediction[]; onClose: () => void }) {
  return (
    <section className="modal open" aria-label="Running predictions" onClick={(event) => event.target === event.currentTarget && onClose()}>
      <div className="modal-card">
        <div className="modal-head"><h3>Running Predictions</h3><button className="button" onClick={onClose}>Close</button></div>
        <div className="modal-body">
          <div className="running-list">
            {running.length ? running.map((item) => (
              <div key={item.id} className="running-row">
                <div className="running-detail"><strong>{item.question}</strong><span className="meta">{item.answer} · {item.coins} coins · approx. {item.returns}%</span></div>
                <b className="running-label">Running</b>
              </div>
            )) : <div className="running-row"><span>No running predictions</span><b className="accent-gold">0</b></div>}
          </div>
        </div>
      </div>
    </section>
  );
}

function InfoModal({ onClose }: { onClose: () => void }) {
  return (
    <section className="modal open" aria-label="Game information" onClick={(event) => event.target === event.currentTarget && onClose()}>
      <div className="modal-card">
        <div className="modal-head"><h3>Info</h3><button className="button" onClick={onClose}>Close</button></div>
        <div className="modal-body">
          <div className="info-block"><h4>How to Play</h4><ol><li>Login to your account.</li><li>Claim free coins when the claim timer is ready.</li><li>Select one question before it closes.</li><li>Choose an answer and the number of coins to use.</li><li>Click Predict. Your prediction will stay in Running until the result is announced.</li></ol></div>
          <div className="info-block"><h4>Reward</h4><ul><li>Monthly Top 10 is based on monthly performance.</li><li>Coin balance is separate from ranking.</li><li>The monthly winner receives a reward.</li><li>Reward proof will be shown after it is completed.</li></ul></div>
          <div className="info-block"><h4>Question Time</h4><ul><li>Each question has its own closing countdown.</li><li>When a question closes, it disappears from the open list.</li><li>Submitted predictions stay in Running while waiting for the result.</li></ul></div>
          <div className="info-block"><h4>Language</h4><div id="google_translate_element" /></div>
        </div>
      </div>
    </section>
  );
}
