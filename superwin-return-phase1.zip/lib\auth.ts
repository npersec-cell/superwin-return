export type DemoUser = {
  id: string;
  clerkUserId: string;
  email: string;
  role: "user" | "admin";
};

export async function getCurrentUser(): Promise<DemoUser | null> {
  // Phase 1 placeholder.
  // Phase 2 will replace this with Clerk auth() + database user sync.
  return {
    id: "demo-user-id",
    clerkUserId: "demo-clerk-user-id",
    email: "demo@superwin.local",
    role: "user"
  };
}

export async function requireUser(): Promise<DemoUser> {
  const user = await getCurrentUser();
  if (!user) {
    throw new Error("Unauthorized");
  }
  return user;
}
