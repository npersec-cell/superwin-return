import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    ok: true,
    data: [],
    message: "Phase 1 stub. Phase 2 will read open predictions from Supabase."
  });
}
