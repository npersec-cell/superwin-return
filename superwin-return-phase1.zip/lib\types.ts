export type UserRole = "user" | "admin";
export type UserStatus = "active" | "suspended" | "banned";
export type LedgerType = "claim" | "predict" | "payout" | "refund" | "fee" | "adjustment";
export type PredictionStatus = "draft" | "open" | "closed" | "resolved" | "canceled";
export type EntryStatus = "running" | "won" | "lost" | "refunded";
export type RewardStatus = "pending" | "contacting" | "completed" | "canceled";

export type ApiResponse<T> = {
  ok: boolean;
  data?: T;
  error?: string;
};
